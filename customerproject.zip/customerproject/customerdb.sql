create database customerdb;
use customerdb;
create table customer
(
id int primary key auto_increment,
First_Name varchar(50),
Last_Name varchar(50),
EMAIL varchar(50)
);
use customerdb;
insert into customer(First_Name,Last_Name,EMAIL)
values ('Monika','Pansare','monikapansare@gmail.com');